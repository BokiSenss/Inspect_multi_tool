import time, os, requests, random, os.path
from colorama import Fore
from util.plugins.commun import * 

def settingstheme():
    setTitle("Inspect Settings Changer")
    clear()
    settingscyclertitle()

    print(f"""{y}[{Fore.LIGHTred_EX }>{y}]{b} OVO JE SVE STO MOZES PROMJENITI:\n          {y}[{w}1{y}]{b} STATUS\n          {y}[{w}2{y}]{b} BOJA TEME\n          {y}[{w}3{y}]{b} JEZIK\n\n""")
    choice = input(f"""{y}[{Fore.LIGHTRED_EX }--->{y}]{b} STO ZELIS PROMJENITI: """)

    if choice == "1":
        print(f"\n{y}[{b}>{y}]{w} NAPISI TOKEN ACC-a KOJM ZELIS PROMJENITI STATUS")
        token = input(f"{y}[{b}--->{y}]{b} TOKEN: ")
        print(f"\n{y}[{b}>{y}]{w} KOLKO STATUSA OCES PROMJENITI? (max 4)")
        statue_number = int(input(f"{y}[{b}--->{y}]{b} KOLICINA: "))
        print(f"\n{y}[{b}>{y}]{w} STAVI KOLKO SEKUNDI (Recommended time: 5)")
        times = int(input(f"{y}[{b}--->{y}]{b} VRIJEME: "))
        print("\n")
        statues = []

        headers = {'Authorization': token, 'Content-Type': 'application/json'}

        if statue_number >= 1 and statue_number <= 4:
            for loop in range(0, statue_number):
                print(f"""{y}[{w}>{y}]{w} IZABERI CUSTOM STATUS{loop+1}""")
                choice = str(input(f"""{y}[{b}--->{y}]{b} STATUS{loop+1}: """))
                statues.append(choice)
        else:
            print(f"""\n{y}[{b}>{y}]{w} NETOCAN BROJ STATUSA""")
            input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
            main()

        input(f"""\n{y}[{b}--->{y}]{b} PRITISNITER DA ZAPOCNES!""")
        clear()
        while True:
            for i in range(len(statues)):
                CustomStatus = {"custom_status": {"text": statues[i]}}
                try:
                    r = requests.patch("https://discord.com/api/v9/users/@me/settings", headers=headers, json=CustomStatus)
                    print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{b} STATUS JE PROMJENJEN NA "{statues[i]}" """)
                    i += 1
                    time.sleep(times)
                except Exception as e:
                    print(f"{y}[{Fore.LIGHTRED_EX }!{y}]{w} ERROR: {e}")
                    time.sleep(times)

    elif choice == "2":
        print(f"""{y}[{b}>{y}]{w} NAPISI TOKEN NA KOJEG ZELIS DA SE PROMJENI TEMA""")
        token = input(f"""{y}[{b}--->{y}]{b} TOKEN: """)

        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        r = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
        if r.status_code == 200:
            print(f"""\n{y}[{w}>{y}]{w} NAPISI KOLICINU PROMJENA: """)
            amount = int(input(f"""{y}[{b}--->{y}]{b} KOLICINA: """))
            print()
            from itertools import cycle
            modes = cycle(["light", "dark"])
            clear()
            for i in range(amount):
                print(f"""{y}[{Fore.LIGHTRED_EX }{i+1}{y}]{b} TEMA JE PROMJENJENA""")
                time.sleep(0.5)
                setting = {'theme': next(modes)}
                requests.patch("https://discord.com/api/v8/users/@me/settings", headers=headers, json=setting)
            clear()
            settingscyclertitle()
            print(f"""{y}[{Fore.LIGHTGREEN_EX }!{y}]{w} PROMJENA JE USPJESNO ZAVRSENA""")
            input(f"""{y}[{b}#{y}]{w} PRITISNI ENTER DA IZADJES""")
            main()
        else:
            print(f"""          {y}[{Fore.LIGHTRED_EX}>{y}]{w} POGRIJESAN TOKEN""")
            input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
            main()
    elif choice == "3":
        print(f"""{y}[{b}>{y}]{w} POSTAVI TOKEN NA KOJEG ZELIS PROMJENITI JEZIK""")
        token = input(f"""{y}[{b}--->{y}]{b} TOKEN: """)

        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        r = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
        if r.status_code == 200:
            print(f"""\n{y}[{b}>{y}]{w} NAPISI BROJ PROMJENA : """)
            amount = int(input(f"""{y}[{b}--->{y}]{b} KOLICINA: """))
            print()
            clear()
            for i in range(amount):
                print(f"""{y}[{Fore.LIGHTRED_EX }{i+1}{y}]{b} JEZIK JE USPJESNO PROMJENJEN""")
                time.sleep(1)
                setting = {'locale': random.choice(['ja', 'zh-TW', 'ko', 'zh-CN', 'th', 'uk', 'ru', 'el', 'cs'])}
                requests.patch("https://discord.com/api/v7/users/@me/settings", headers=headers, json=setting)
            clear()
            settingscyclertitle()
            print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} PROMJENA JE USPJESNO ZAVRSENA""")
            input(f"""{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
            main()
        else:
          print(f"""          {y}[{Fore.LIGHTRED_EX }>{y}]{w} POGRIJESNI TOKEN""")
          input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
          main()
    else:
        print(f"""          {y}[{Fore.LIGHTRED_EX }>{y}]{w} POGRIJESNO STE IZABRALI""")
        input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
        main()
          
settingstheme()
