import os
import requests
from colorama import Fore
from util.plugins.commun import * 

setTitle("Inspect Webhook Deleter")
clear()
webhremovertitle()

def webhooksremover():
    try:
        print(f"""{y}[{b}>{y}]{w} NAPISITE WEBHOOK KJI ZELITE IZBRISATI! """)
        webhook = input(f"""{y}[{w}--->{y}]{b} WEBHOOK LINK: """)
        requests.delete(webhook.rstrip())
        print(f"""\n{y}[{Fore.LIGHTRED_EX }!{y}]{b} WEBHOOK JE IZBRISAN!""")
        input(f"""\n{y}[{w}--->{y}]{b} PRITISNITE ENTER ZA EXIT!""")
        main()
    except:
        print(f"""\n{y}[{Fore.LIGHTRED_EX }!{y}]{w} WEBHOOK NE MOZE BITI IZBRISAN!""")
        input(f"""\n{y}[{w}--->{y}]{b} PRITISNITE ENTER ZA EXIT!""")
        main()
          
webhooksremover()