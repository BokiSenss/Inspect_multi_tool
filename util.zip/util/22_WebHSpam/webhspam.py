import requests
import time
from colorama import Fore
import os
import ctypes
from util.plugins.commun import * 

def webhookspam():
    setTitle("WebHook Spammer")
    clear()
    webhspamtitle()
    print(f"""{y}[{w}>{y}]{w} NAPISI WEBHOOK ZA SPAMANJE """)
    webhook = input(f"""{y}[{b}--->{y}]{b} WEBHOOK: """)
    print(f"""\n{y}[{w}>{y}]{w} NAPISI PORUKU ZA SPAMANJE """)
    message = input(f"""{y}[{b}--->{y}]{b} PORUKA: """)
    print(f"""\n{y}[{w}>{y}]{w} KOLIKO PORUKA!(s) """)
    timer = input(f"""{y}[{b}--->{y}]{b} KOLICINA: """)
    input(f"""\n\n{y}[{b}--->{y}]{b} PRITISNI ENTER""")

    try:
        timeout = time.time() + 1 * float(timer)

        while time.time() < timeout:
            response = requests.post(
                webhook,
                json = {"content" : message},
                params = {'wait' : True}
            )
            clear()
            time.sleep(1)
            if response.status_code == 204 or response.status_code == 200:
                print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} PORUKE SU POSLANE !""")
            elif response.status_code == 429:
                print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} Rate limited ({response.json()['retry_after']}ms)""")
                time.sleep(response.json()["retry_after"] / 1000)
            else:
                print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} NIJE TOCAN KOD: {response.status_code}""")
    except:
        print(f"""      {y}[{Fore.LIGHTRED_EX }!{y}]{b} TVOJ REQUEST JE NE ISPRAVAN !""")
        time.sleep(2)
        clear()
        main()

    clear()
    webhspamtitle()
    print(f"""{y}[{Fore.LIGHTGREEN_EX }!{y}]{w} VAS WEBHOOK JE ISPAMAN! """)
    input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER UKOLIKO ZELIS IZACI!""")
    main()
    
webhookspam()
