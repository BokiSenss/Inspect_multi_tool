import requests
from colorama import Fore
from util.plugins.commun import * 

def serverlookup():
    setTitle("Inspect Server Lookup")
    clear()
    serverlookuptitle()
    print(f"""{y}[{Fore.LIGHTRED_EX }>{y}]{w} OVDJE JE SVE STO MOZETE PRONACI: \n\n""")
    print(f"""          {y}[{w}>{y}]{b} Invite Link           {y}[{w}>{y}]{b} Inviter Username      {y}[{w}>{y}]{b} Guild Banner          {y}[{w}>{y}]{b} Guild Splash\n""")
    print(f"""          {y}[{w}>{y}]{b} Channel Name          {y}[{w}>{y}]{b} Inviter ID            {y}[{w}>{y}]{b} Guild Descrpition     {y}[{w}>{y}]{b} Guild Features\n""")
    print(f"""          {y}[{w}>{y}]{b} Channel ID            {y}[{w}>{y}]{b} Guild Name            {y}[{w}>{y}]{b} Custom Invite Link\n""")
    print(f"""          {y}[{w}>{y}]{b} Expiration Date       {y}[{w}>{y}]{b} Guild ID              {y}[{w}>{y}]{b} Verification Level\n\n\n\n""")
    print(f"{y}[{w}+{y}]{w} POSTAVI DISCORD LINK: ")
    invitelink = input(f"""{y}[{b}#{y}]{w} INVITE LINK: """)

    try:
        res = requests.get(f"https://discord.com/api/v9/invites/{invitelink}")
    except:
        input(f"""          {y}[{Fore.LIGHTRED_EX }--->{y}]{b} JEDAN ERROR JE PRONADJEN!""")
        main()

    if res.status_code == 200:
        res_json = res.json()
        invite_link = f'https://discord.gg/{res_json["code"]}'
        invite_channel_name = res_json["channel"]["name"]
        invite_channel_id = res_json["channel"]["id"]
        invite_expires_at = res_json["expires_at"]

        inviter_username = f'{res_json["inviter"]["username"]}#{res_json["inviter"]["discriminator"]}'
        inviter_user_id = res_json["inviter"]["id"]

        server_name = res_json["guild"]["name"]
        server_id = res_json["guild"]["id"]
        banner = res_json["guild"]["banner"]
        description = res_json["guild"]["description"]
        custom_invite_link = res_json["guild"]["vanity_url_code"]
        verification_level = res_json["guild"]["verification_level"]
        splash = res_json["guild"]["splash"]
        features = res_json["guild"]["features"]

        print(f"""\n{y}[{b}>{y}]{w} Invitation Information:""")
        print(f"""          {y}[{w}>{y}]{b} Invite Link: {invite_link}""")
        print(f"""          {y}[{w}>{y}]{b} Channel: {invite_channel_name} ({invite_channel_id})""")
        print(f"""          {y}[{w}>{y}]{b} Expiration Date: {invite_expires_at}\n\n""")

        print(f"""{y}[{b}#{y}]{w} Inviter Information:""")
        print(f"""          {y}[{w}>{y}]{b} Username: {inviter_username}""")
        print(f"""          {y}[{w}>{y}]{b} User ID: {inviter_user_id}\n\n""")

        print(f"""{y}[{b}>{y}]{w} Server Information:""")
        print(f"""          {y}[{w}>{y}]{b} Name: {server_name}""")
        print(f"""          {y}[{w}>{y}]{b} Server ID: {server_id}""")
        print(f"""          {y}[{w}>{y}]{b} Banner: {banner}""")
        print(f"""          {y}[{w}>{y}]{b} Description: {description}""")
        print(f"""          {y}[{w}>{y}]{b} Custom Invite Link: {custom_invite_link}""")
        print(f"""          {y}[{w}>{y}]{b} Verification Level: {verification_level}""")
        print(f"""          {y}[{w}>{y}]{b} Splash: {splash}""")
        print(f"""          {y}[{w}>{y}]{b} Features: {features}""")
        
    else:
        input(f"""          {y}[{Fore.LIGHTRED_EX }>{y}]{w} JEDAN ERROR JE PRONADJEN!""")
        main()
    
    input(f"""\n\n{y}[{b}--->{y}]{b} PRITISNI ENTER ZA NASTAVAK""")
    main()

serverlookup()
