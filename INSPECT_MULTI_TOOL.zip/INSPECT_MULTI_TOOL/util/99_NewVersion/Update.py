import webbrowser

webbrowser.open_new("https://github.com/BokiSenss/Inspect_multi_tool/releases/download/Newwssss/INSPECT_MULTI_TOOL.zip")