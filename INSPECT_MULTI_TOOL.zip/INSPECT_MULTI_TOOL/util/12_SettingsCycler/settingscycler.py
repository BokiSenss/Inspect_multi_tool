import time, os, requests, random, os.path
from colorama import Fore
from util.plugins.commun import * 

def settingstheme():
    setTitle("Inspect Settings Changer")
    clear()
    settingscyclertitle()

    print(f"""{y}[{Fore.LIGHTRED_EX }>{y}]{w} OO DOLE MOZES PROMJENITI:\n\n          {y}[{b}1{y}]{b} Statue\n          {y}[{b}2{y}]{b} Color Theme\n          {y}[{b}3{y}]{b} Language\n\n""")
    choice = input(f"""{y}[{Fore.LIGHTRED_EX }--->{y}]{w} ODABERI STO ZELIS PROMJENITI: """)

    if choice == "1":
        print(f"\n{y}[{b}>{y}]{w} NAPISI TOKEN KOJEM ZELIS PRMJENII STATUE")
        token = input(f"{y}[{b}--->{y}]{w} TOKEN: ")
        print(f"\n{y}[{b}>{y}]{w} KOLIKO STATUES ZELIS PROMJENITI (max 4)")
        statue_number = int(input(f"{y}[{b}--->{y}]{b} KOLICINA: "))
        print(f"\n{y}[{b}>{y}]{w} KOLKO PUTA DA SE MJENJA U SEKUNDAMA (Recommended time: 5)")
        times = int(input(f"{y}[{b}--->{y}]{b} VRIJEME: "))
        print("\n")
        statues = []

        headers = {'Authorization': token, 'Content-Type': 'application/json'}

        if statue_number >= 1 and statue_number <= 4:
            for loop in range(0, statue_number):
                print(f"""{y}[{b}>{y}]{w} IZABERI CUSTOM STATUS #{loop+1}""")
                choice = str(input(f"""{y}[{b}--->{y}]{w} STATUS #{loop+1}: """))
                statues.append(choice)
        else:
            print(f"""\n{y}[{b}>{y}]{w} INVALID NUMBER""")
            input(f"""\n{y}[{b}--->{y}]{w} PRITISNI ENTER DA IZADJES""")
            main()

        input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA ZAPOCNES""")
        clear()
        while True:
            for i in range(len(statues)):
                CustomStatus = {"custom_status": {"text": statues[i]}}
                try:
                    r = requests.patch("https://discord.com/api/v9/users/@me/settings", headers=headers, json=CustomStatus)
                    print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} STATUS JE PROMJENJEN NA "{statues[i]}" """)
                    i += 1
                    time.sleep(times)
                except Exception as e:
                    print(f"{y}[{Fore.LIGHTRED_EX }!{y}]{w} Error: {e}")
                    time.sleep(times)

    elif choice == "2":
        print(f"""{y}[{b}>{y}]{w} STAVI TOKEN KOJEM ZELIS PROMJENITI TEMU""")
        token = input(f"""{y}[{b}--->{y}]{b} TOKEN: """)

        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        r = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
        if r.status_code == 200:
            print(f"""\n{y}[{b}>{y}]{w} NAPISI BROJ PROMJENA : """)
            amount = int(input(f"""{y}[{b}--->{y}]{b} KOLICINA: """))
            print()
            from itertools import cycle
            modes = cycle(["light", "dark"])
            clear()
            for i in range(amount):
                print(f"""{y}[{Fore.LIGHTGREEN_EX }{i+1}{y}]{w} TEMA JE USPJESNO PROMJENJENA""")
                time.sleep(0.5)
                setting = {'theme': next(modes)}
                requests.patch("https://discord.com/api/v8/users/@me/settings", headers=headers, json=setting)
            clear()
            settingscyclertitle()
            print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} PROMJENA JE USPJESNO PROMJENJENA""")
            input(f"""{y}[{b}--->{y}]{w} PRITISNI ENTER DA IZADJES""")
            main()
        else:
            print(f"""          {y}[{Fore.LIGHTRED_EX }>{y}]{w} NETOCAN TOKEN""")
            input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
            main()
    elif choice == "3":
        print(f"""{y}[{w}+{y}]{w} Enter the token of the account you want to Cycle Language""")
        token = input(f"""{y}[{b}#{y}]{w} Token: """)

        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        r = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
        if r.status_code == 200:
            print(f"""\n{y}[{b}>{y}]{w} NAPISI BROJ ROMJENA : """)
            amount = int(input(f"""{y}[{b}--->{y}]{b} KOLICINA: """))
            print()
            clear()
            for i in range(amount):
                print(f"""{y}[{Fore.LIGHTGREEN_EX }{i+1}{y}]{w} JEZIK JE USPJESNO PROMJENJEN""")
                time.sleep(1)
                setting = {'locale': random.choice(['ja', 'zh-TW', 'ko', 'zh-CN', 'th', 'uk', 'ru', 'el', 'cs'])}
                requests.patch("https://discord.com/api/v7/users/@me/settings", headers=headers, json=setting)
            clear()
            settingscyclertitle()
            print(f"""{y}[{Fore.LIGHTRED_EX }!{y}]{w} PROMJENA JE USPJESNO ZAVRSENA""")
            input(f"""{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
            main()
        else:
          print(f"""          {y}[{Fore.LIGHTRED_EX }>{y}]{w} NETOCAN TOKEN""")
          input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
          main()
    else:
        print(f"""          {y}[{Fore.LIGHTRED_EX }#{y}]{w} POGRIJESNO STE ODABRALI""")
        input(f"""\n{y}[{b}--->{y}]{b} PRITISNI ENTER DA IZADJES""")
        main()
          
settingstheme()
